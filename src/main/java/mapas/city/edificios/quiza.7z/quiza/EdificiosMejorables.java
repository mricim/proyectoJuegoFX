package main.java.mapas.city.edificios.quiza;

import com.sun.istack.internal.NotNull;

public class EdificiosMejorables extends Edificios implements ImageGetter{
    @NotNull
    private int nivel;
    @NotNull
    private int nivelMax;
    @NotNull
    private int costeOro;
    @NotNull
    private int costeMadera;
    @NotNull
    private int costePiedra;
    @NotNull
    private int costehierro;
    private int necesitaTrabajadoresXmin;

    public EdificiosMejorables(int id, String nombre, boolean destruible, int nivel, int nivelMax, int costeOro, int costeMadera, int costePiedra, int costehierro,int necesitaTrabajadoresXmin) {
        super(id, nombre, destruible);
        this.nivel = nivel;
        this.nivelMax = nivelMax;
        this.costeOro = costeOro;
        this.costeMadera = costeMadera;
        this.costePiedra = costePiedra;
        this.costehierro = costehierro;
        this.necesitaTrabajadoresXmin=necesitaTrabajadoresXmin;
    }

    public String getImage() {
        return String.valueOf(getId() + "_" + nivel);
    }

    @Override
    public String getImageClicable() {
        return String.valueOf(getId() + "_" + nivel + "-clic");
    }
}
