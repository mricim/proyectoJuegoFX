package main.java.mapas.city.edificios.quiza;

import com.sun.istack.internal.NotNull;

import java.util.Objects;

public class Edificios implements ImageGetter{
    @NotNull
    private int id;
    @NotNull
    private String nombre;
    @NotNull
    private boolean destruible;

    protected Edificios(int id) {
        this.id = id;
    }

    public Edificios(int id, String nombre, boolean destruible) {
        this.id = id;
        this.nombre = nombre;
        this.destruible = destruible;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean isDestruible() {
        return destruible;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Edificios)) return false;
        Edificios edificios = (Edificios) o;
        return getId() == edificios.getId();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }


    @Override
    public String getImage() {
        return null;
    }

    @Override
    public String getImageClicable() {
        return null;
    }
}

interface ImageGetter {
    abstract public String getImage();
    abstract public String getImageClicable();
}