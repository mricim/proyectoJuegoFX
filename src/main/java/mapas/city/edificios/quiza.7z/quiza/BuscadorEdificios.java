package main.java.mapas.city.edificios.quiza;

import static main.java.mapas.city.Main.listaEdificios;

public class BuscadorEdificios {
    /*
    public BuscadorEdificios(int id) {
        super(id);
    }
    static public Edificios returnEdificio(int edificioID){
        return(Edificios) listaEdificios.get(listaEdificios.indexOf(new BuscadorEdificios(edificioID)));
    }

     */
}
